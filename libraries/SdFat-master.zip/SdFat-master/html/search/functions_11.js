var searchData=
[
  ['ungetc',['ungetc',['../class_stdio_stream.html#ac00e0dd906c2e857ece53794c6c92786',1,'StdioStream']]],
  ['unsetf',['unsetf',['../classios__base.html#a3bf7d054a433ed15e8b984e16f630fa4',1,'ios_base']]],
  ['uppercase',['uppercase',['../ios_8h.html#af5d5e1a0effa1b500bb882feed5a2061',1,'ios.h']]],
  ['usespitransactions',['useSpiTransactions',['../class_sd_spi_base.html#a0a13df4c86ec6978878b63386ee65007',1,'SdSpiBase::useSpiTransactions()'],['../class_sd_spi.html#a048d54bb93f2f2f86d9a499605dd1427',1,'SdSpi::useSpiTransactions()'],['../class_sd_spi_lib.html#ad1b8c659d1a7e90b3a43c4e87835245b',1,'SdSpiLib::useSpiTransactions()'],['../class_sd_spi_soft.html#aa269a343795b07845e6280db8b36dccb',1,'SdSpiSoft::useSpiTransactions()']]]
];
